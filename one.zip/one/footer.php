</section>

<footer class="footer" id="footer">
    <section class="container">
	    <div class="row">
	    	<div class="col-md-8">
	    		<p>&copy; <?php the_time('Y'); ?> | <?php bloginfo( 'name' ); ?>. Alle rechten voorbehouden. | <a href="/sitemap/">Sitemap</a> | <a href="/disclaimer/">Disclaimer</a> </p>
	    	</div>
	    	<div class="col-md-4 alignright">
	    	</div>
	    </div>
	</section>
</footer>
<?php wp_head(); ?>

<?php wp_footer();?>
</body>
</html>